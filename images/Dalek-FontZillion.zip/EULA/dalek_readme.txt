
=== DALEK ===

Keith Bates / K-Type © 2005, 2007 (version 3.02)
www.k-type.com    -    info@k-type.com

Dalek is a full font based on the lettering used in the Dalek Book of 1964 and in the Daleks strip in TV21 comic, spin-offs from the UK science fiction TV show, Doctor Who. The font has overtones of Phoenician, Greek and Runic alphabets.

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------